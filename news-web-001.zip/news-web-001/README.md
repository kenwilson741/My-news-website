# news web 001

A Pen created on CodePen.io. Original URL: [https://codepen.io/ken-wilson-willie/pen/zYXXjGp](https://codepen.io/ken-wilson-willie/pen/zYXXjGp).

